'use strict';

import React, { AppRegistry } from 'react-native';

import DashBoard from './components/DashBoard';

AppRegistry.registerComponent('foodDelivery', () => DashBoard);
