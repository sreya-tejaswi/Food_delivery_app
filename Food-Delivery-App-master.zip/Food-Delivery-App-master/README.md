# Food Delivery Mobile App

A food delivery application.
you can use this app for food delivery

![alt tag](https://raw.githubusercontent.com/AndroConsis/Food-Delivery-App/master/components/images/drawer_screenshot.png)
![alt tag](https://raw.githubusercontent.com/AndroConsis/Food-Delivery-App/master/components/images/menu_screenshot.png)
