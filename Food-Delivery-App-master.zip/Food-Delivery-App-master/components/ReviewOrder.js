'use strict';

import React, { Component } from 'react';

import {
  StyleSheet,
  View,
  Text,
} from 'react-native';

class ReviewOrder extends Component {
  render() {
    return (
      <View>
      	<Text>Review Order</Text>
      </View>
    );
  }
}


const styles = StyleSheet.create({

});


export default ReviewOrder;